class Image {
    constructor(path, width, height) {
        this.path = path
        this.width = width
        this.height = height
    }
}

export { Image }