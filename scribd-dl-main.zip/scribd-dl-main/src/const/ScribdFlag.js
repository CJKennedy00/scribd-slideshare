const DEFAULT = "/d"
const IMAGE = "/i"

export { DEFAULT, IMAGE }